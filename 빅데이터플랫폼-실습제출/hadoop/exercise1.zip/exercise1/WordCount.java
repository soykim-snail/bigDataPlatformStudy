package exercise1;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class WordCount {
	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		conf.set("fs.default.name", "hdfs://192.168.111.120:9000");

		Job job = Job.getInstance(conf, "WordCount");//Job 객체 생성, Job이름을 준다. 

		/************* Job 객체 세팅 ************************/
		job.setJarByClass(WordCount.class); //드라이버
		job.setMapperClass(WordCountMapper.class);
		job.setReducerClass(WordCountReducer.class);

		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);

		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);

		/******* 읽을 파일 설정하고, 내보낼 위치 설정 **************/
		FileInputFormat.addInputPath(job, new Path("/edudata/fruits.txt"));
		FileOutputFormat.setOutputPath(job, new Path("/result/exerout1")); //폴더지정~!! (파일명은 정해져있음)

		job.waitForCompletion(true);
		System.out.println("처리가 완료되었습니다.");
	}
}