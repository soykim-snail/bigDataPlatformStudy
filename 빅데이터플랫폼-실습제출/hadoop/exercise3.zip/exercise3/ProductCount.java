package exercise3;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class ProductCount {

	public static void main(String[] args) throws Exception {
		// HADOOP DFS 기동과 세팅
		Configuration conf = new Configuration();
		conf.set("fs.defaultFS", "hdfs://192.168.111.120:9000");
		// Yarn 기동과 세팅
		Job job = Job.getInstance(conf, "PRODUCT_COUNT"); // IOException 던짐.
		job.setJarByClass(ProductCount.class);
		job.setMapperClass(ProductMapper.class);
		job.setReducerClass(ProductReducer.class);
		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		FileInputFormat.addInputPath(job, new Path("/edudata/product_click.log"));
		FileOutputFormat.setOutputPath(job, new Path("/result/exerout3"));
		job.waitForCompletion(true);
		// 표준 출력
		System.out.println("처리완료");	
	}

}
