package exercise3;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class ProductMapper extends Mapper<LongWritable, Text, Text, IntWritable> {

	// 아웃풋 세팅
	private final static IntWritable one = new IntWritable(1);
	private Text product = new Text();
	
	// map 함수 오버라이팅
	@Override
	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		String productString = value.toString().split("\\s")[1];		
		product.set(productString);		
		context.write(product, one);
	}
	
}
